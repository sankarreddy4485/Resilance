package com.javasoft.serviceB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceBApplicationTests {

	@Test
	void contextLoads() {
	}

}
